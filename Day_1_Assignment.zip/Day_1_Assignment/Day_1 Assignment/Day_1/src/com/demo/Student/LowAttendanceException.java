package com.demo.Student;

public class LowAttendanceException extends Exception {
	public LowAttendanceException(String message) {
        super(message);
    }
}
